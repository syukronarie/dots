---@type MappingsTable
local M = {}

M.general = {
  n = {
    [";"] = { ":", "enter command mode", opts = { nowait = true } },
  },
  v = {
    [">"] = { ">gv", "indent"},
  },
}

-- more keybinds!

M.lspconfig = {
  n = {
    ["<C-k>"] = {
      function()
        vim.diagnostic.goto_prev { float = { border = "rounded" } }
      end,
      "Goto prev",
    },

    ["<C-j>"] = {
      function()
        vim.diagnostic.goto_next { float = { border = "rounded" } }
      end,
      "Goto next",
    },

    ["<C-space>"] = {
      function()
        vim.lsp.buf.code_action()
      end,
      "LSP code action",
    }
  },

  i = {
    ["<C-space>"] = {
      function()
        vim.lsp.buf.code_action()
      end,
      "LSP code action",
    }
  },

  v = {
    ["<C-space>"] = {
      function()
        vim.lsp.buf.code_action()
      end,
      "LSP code action",
    }
  }

}

return M
